﻿using CoffeeShopManagementSystem.UI.Balance_Reload;
using CoffeeShopManagementSystem.UI.BalanceTransfer;
using CoffeeShopManagementSystem.UI.Customer_Entry_Details;
using CoffeeShopManagementSystem.UI.Daily_Report;
using CoffeeShopManagementSystem.UI.Product_Add;
using CoffeeShopManagementSystem.UI.Product_Order;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopManagementSystem
{
    public partial class AdminDashbord : Form
    {
        public AdminDashbord()
        {
            InitializeComponent();
        }

        private void customerEntryButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            CustomerEntryDetails aCustomerEntryDetails = new CustomerEntryDetails();
            aCustomerEntryDetails.Parent = this;
            adminpanel.Controls.Add(aCustomerEntryDetails);
            aCustomerEntryDetails.Dock = DockStyle.Fill;
        }

        private void customerReloadButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            BalanceReloadForm balanceReloadForm = new BalanceReloadForm();
            balanceReloadForm.Parent = this;
            adminpanel.Controls.Add(balanceReloadForm);
            balanceReloadForm.Dock = DockStyle.Fill;
        }

        private void balanceTransferButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            BalanceTransferForm balanceTransfer = new BalanceTransferForm();
            balanceTransfer.Parent = this;
            adminpanel.Controls.Add(balanceTransfer);
            balanceTransfer.Dock = DockStyle.Fill;
        }

        private void productSetupButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            ProductAdd aProductAdd = new ProductAdd();
            aProductAdd.Parent = this;
            adminpanel.Controls.Add(aProductAdd);
            aProductAdd.Dock = DockStyle.Fill;
        }

        private void productOrderButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            ProductOrderPaymentDetails productOrderPaymentDetails = new ProductOrderPaymentDetails();
            productOrderPaymentDetails.Parent = this;
            adminpanel.Controls.Add(productOrderPaymentDetails);
            productOrderPaymentDetails.Dock = DockStyle.Fill;
        }

        private void dailyReportButton_Click(object sender, EventArgs e)
        {
            adminpanel.Controls.Clear();
            DailyReport aDailyReport = new DailyReport();
            aDailyReport.Parent = this;
            adminpanel.Controls.Add(aDailyReport);
            aDailyReport.Dock = DockStyle.Fill;
        }
    }
}
