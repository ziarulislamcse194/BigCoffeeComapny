﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.DAL.Model
{
    public class BalanceTransferModel
    {
        public int BalanceTransferID { get; set; }
        public string BalanceTransferAccount { get; set; }
        public string TransferCustomerName { get; set; }
        public string BalanceReceiveAccount { get; set; }
        public string ReceiveCustomerName { get; set; }
        public int TransferBalance { get; set; }
    }
}
