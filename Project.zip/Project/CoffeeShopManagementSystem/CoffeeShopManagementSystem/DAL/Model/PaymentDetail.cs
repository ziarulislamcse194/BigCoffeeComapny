﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.DAL.Model
{
    public class PaymentDetail
    {
        public int PaymentDetailID { get; set; }
        public double Subtotal { get; set; }
        public double Discount { get; set; }
        public double ServiceTex { get; set; }
        public double GST { get; set; }
        public double Rounding { get; set; }
        public double GrandTotal { get; set; }
        public string UserId { get; set; }
        public string SixDigitPin { get; set; }
        public DateTime DailyReportDate { get; set; }
        public double AccountBalance { get; set; }
        public double MadePayment { get; set; }
        public double NewBalance { get; set; }
    }
}
