﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class BDGetWay
    {
        private SqlConnection connectionObj;
        public SqlCommand SqlcommandObj;
        public BDGetWay()
        {
            connectionObj = new SqlConnection(ConfigurationManager.ConnectionStrings["CoffeeShowManagementApp"].ConnectionString);
            SqlcommandObj = new SqlCommand();
        }

        public SqlConnection SqlConnectionObj
        {
            get
            {
                return connectionObj;
            }
        }

        public SqlCommand SqlSqlcommandObj
        {
            get
            {
                SqlcommandObj.Connection = connectionObj;
                SqlcommandObj.CommandTimeout = 50000;
                return SqlcommandObj;
            }
        }
    }
}
