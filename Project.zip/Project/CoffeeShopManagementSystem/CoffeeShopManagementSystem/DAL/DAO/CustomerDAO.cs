﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class CustomerDAO:BDGetWay
    {
        public string InsertCustomer(CustomerEntry aCustomerEntry)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into CustomerEntry values ('{0}','{1}','{2}','{3}', {4});",
                    aCustomerEntry.Name, aCustomerEntry.AccountNumber, aCustomerEntry.AccountPin, aCustomerEntry.Address, 
                    aCustomerEntry.ContactNumber);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Customer has been saved successfully.";


            }
            catch (Exception ex)
            {
                result = "Customer couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public CustomerEntry GetCustomerName(string name)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from CustomerEntry where Name='{0}'", name);

                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        customerEntry = ToReadAllCustomerInfo(reader);
                    }
                }


            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + ". Error Occured. Please contact to your administrator.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return customerEntry;
        }

        private CustomerEntry ToReadAllCustomerInfo(SqlDataReader reader)
        {
            CustomerEntry aCustomerEntry = new CustomerEntry();

            try
            {
                if (reader["CustomerID"] != DBNull.Value)
                {
                    aCustomerEntry.CustomerID = Convert.ToInt32(reader["CustomerID"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Name"] != DBNull.Value)
                {
                    aCustomerEntry.Name = reader["Name"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["AccountNumber"] != DBNull.Value)
                {
                    aCustomerEntry.AccountNumber = reader["AccountNumber"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["AccountPin"] != DBNull.Value)
                {
                    aCustomerEntry.AccountPin = reader["AccountPin"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Address"] != DBNull.Value)
                {
                    aCustomerEntry.Address = reader["Address"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["ContactNumber"] != DBNull.Value)
                {
                    aCustomerEntry.ContactNumber = Convert.ToInt32(reader["ContactNumber"]);
                }
            }
            catch
            {
            }

            return aCustomerEntry;
        }

        public string UpdateCustomer(CustomerEntry customerEntry)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("UPDATE CustomerEntry SET Name = '{1}',AccountNumber = '{2}',AccountPin='{3}'," +
                    "Address='{4}',ContactNumber={5} where CustomerID = {0} ",customerEntry.CustomerID, customerEntry.Name, 
                    customerEntry.AccountNumber, customerEntry.AccountPin, customerEntry.Address, customerEntry.ContactNumber);
                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Customer updated Sucessfully.";

            }
            catch (Exception ex)
            {
                result = "Customer couldn't updated.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }


        public bool DeleteCustomer(int id)
        {
            bool result = false;
            try
            {
                SqlConnectionObj.Open();
                String Query = string.Format("DELETE FROM CustomerEntry WHERE CustomerID={0}", id);
                SqlSqlcommandObj.CommandText = Query;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }


        public List<CustomerEntry> GetCustomerList()
        {
            List<CustomerEntry> customerEntries = new List<CustomerEntry>();

            try
            {


                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM CustomerEntry");
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        CustomerEntry customerEntry = new CustomerEntry();
                        customerEntry = ToReadAllCustomerInfo(reader);
                        customerEntries.Add(customerEntry);

                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception("Data not Found!!!", ex);

            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return customerEntries;
        }



        public CustomerEntry GetAccountNumberAndAccontPin(string userId, string sixdigitPin)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from CustomerEntry where AccountNumber='{0}' and AccountPin = '{1}'", userId, sixdigitPin);

                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        customerEntry = ToReadAllCustomerInfo(reader);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + "Don't mach Account Number and Account Pin.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return customerEntry;
        }

        public CustomerEntry GetByCustomerId(int id)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from CustomerEntry where CustomerID= {0}", id);

                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        customerEntry = ToReadAllCustomerInfo(reader);
                    }
                }


            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + ". Error Occured. Please contact to your administrator.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return customerEntry;
        }



    }
}
