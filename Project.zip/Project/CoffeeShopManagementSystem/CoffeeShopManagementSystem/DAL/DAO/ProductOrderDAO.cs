﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class ProductOrderDAO:BDGetWay
    {
        public string InsertProductOrder(ProductOrder productOrder)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into ProductOrder values ({0},'{1}','{2}',{3}, '{4}', {5});",
                    productOrder.ProductID, productOrder.ProductName, productOrder.Category, productOrder.Price, productOrder.Size, productOrder.Quantity);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Product Order has been saved successfully.";
                
            }
            catch (Exception ex)
            {
                result = "Product Order couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public bool DeleteProductOrder(int id)
        {
            bool result = false;
            try
            {
                SqlConnectionObj.Open();
                String Query = string.Format("DELETE FROM ProductOrder WHERE ProductOrderID={0}", id);

                SqlSqlcommandObj.CommandText = Query;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public List<ProductOrder> GetAllProductOrder()
        {
            List<ProductOrder> productOrders = new List<ProductOrder>();
            try
            {
                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM ProductOrder");
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        ProductOrder productOrder = new ProductOrder();
                        productOrder = ToReadAllProductOrderInfo(reader);
                        productOrders.Add(productOrder);
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception("Data not Found!!!", ex);

            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return productOrders;
        }

        private ProductOrder ToReadAllProductOrderInfo(SqlDataReader reader)
        {
            ProductOrder productOrder = new ProductOrder();

            try
            {
                if (reader["ProductOrderID"] != DBNull.Value)
                {
                    productOrder.ProductOrderID = Convert.ToInt32(reader["ProductOrderID"]);
                }
            }
            catch
            {

            }

            try
            {
                if (reader["ProductID"] != DBNull.Value)
                {
                    productOrder.ProductID = Convert.ToInt32(reader["ProductID"]);
                }
            }
            catch
            {

            }

            try
            {
                if (reader["ProductName"] != DBNull.Value)
                {
                    productOrder.ProductName = reader["ProductName"].ToString();
                }
            }
            catch
            {

            }

            
            try
            {
                if (reader["Category"] != DBNull.Value)
                {
                    productOrder.Category = reader["Category"].ToString();
                }
            }
            catch
            {

            }

            try
            {
                if (reader["Price"] != DBNull.Value)
                {
                    productOrder.Price = Convert.ToDouble(reader["Price"]);
                }
            }
            catch
            {

            }


            try
            {
                if (reader["Size"] != DBNull.Value)
                {
                    productOrder.Size = reader["Size"].ToString();
                }
            }
            catch
            {

            }

            try
            {
                if (reader["Quantity"] != DBNull.Value)
                {
                    productOrder.Quantity = Convert.ToInt32(reader["Quantity"]);
                }
            }
            catch
            {

            }

            return productOrder;
        }
    }
}
