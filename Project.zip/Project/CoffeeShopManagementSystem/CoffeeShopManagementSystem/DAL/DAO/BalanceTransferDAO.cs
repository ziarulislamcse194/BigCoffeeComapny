﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class BalanceTransferDAO:BDGetWay
    {
        public string InsertBalanceTransfer(BalanceTransferModel balanceTransferModel)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into BalanceTransfer values ('{0}','{1}','{2}','{3}',{4});",
                    balanceTransferModel.BalanceTransferAccount, balanceTransferModel.TransferCustomerName, balanceTransferModel.BalanceReceiveAccount,
                    balanceTransferModel.ReceiveCustomerName, balanceTransferModel.TransferBalance);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Balance Transfer has been saved successfully.";


            }
            catch (Exception ex)
            {
                result = "Balance Transfer couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }
    }
}
