﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class BalanceReloadDAO:BDGetWay
    {
        public string InsertBalance(BalanceReoaad balanceReoaad)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into Balance values ({0},'{1}','{2}',{3});",
                    balanceReoaad.CustomerID, balanceReoaad.AccountNumber, balanceReoaad.CustomerName, balanceReoaad.Balance);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Balance has been saved successfully.";
                
            }
            catch (Exception ex)
            {
                result = "Balance couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public BalanceReoaad GetAllAccountNumber(BalanceReoaad balanceReoaad)
        {
            BalanceReoaad abalanceReoaad = new BalanceReoaad();
            try
            {
                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM Balance WHERE AccountNumber ='{0}'", balanceReoaad.AccountNumber);
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        abalanceReoaad = ToReadBalabceRealod(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Data not Found!!!", ex);
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return abalanceReoaad;
        }

        private BalanceReoaad ToReadBalabceRealod(SqlDataReader reader)
        {
            BalanceReoaad balanceReoaad = new BalanceReoaad();

            try
            {
                if (reader["BalanceReloadID"] != DBNull.Value)
                {
                    balanceReoaad.BalanceReloadID = Convert.ToInt32(reader["BalanceReloadID"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["CustomerID"] != DBNull.Value)
                {
                    balanceReoaad.CustomerID = Convert.ToInt32(reader["CustomerID"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["AccountNumber"] != DBNull.Value)
                {
                    balanceReoaad.AccountNumber = reader["AccountNumber"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["CustomerName"] != DBNull.Value)
                {
                    balanceReoaad.CustomerName = reader["CustomerName"].ToString();
                }
            }
            catch
            {
            }


            try
            {
                if (reader["Balance"] != DBNull.Value)
                {
                    balanceReoaad.Balance = Convert.ToDouble(reader["Balance"]);
                }
            }
            catch
            {
            }


            return balanceReoaad;
        }

        public BalanceReoaad GetByCustomerId(int id)
        {
            BalanceReoaad abalanceReoaad = new BalanceReoaad();
            try
            {
                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM Balance WHERE CustomerID ={0}", id);
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        abalanceReoaad = ToReadBalabceRealod(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Data not Found!!!", ex);
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return abalanceReoaad;
        }

        public string UpdateBalance(BalanceReoaad balanceReoaad)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("UPDATE Balance SET CustomerID = {0}, AccountNumber = '{1}',CustomerName = '{2}', Balance='{3}' where BalanceReloadID = {4}", 
                    balanceReoaad.CustomerID, balanceReoaad.AccountNumber, balanceReoaad.CustomerName, balanceReoaad.Balance, 
                    balanceReoaad.BalanceReloadID);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Balance updated Sucessfully.";

            }
            catch (Exception ex)
            {
                result = "Balance couldn't updated.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }


        public BalanceReoaad GetByAccountNumber(string usId)
        {
            BalanceReoaad abalanceReoaad = new BalanceReoaad();
            try
            {
                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM Balance WHERE AccountNumber ='{0}'", usId);
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        abalanceReoaad = ToReadBalabceRealod(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Data not Found!!!", ex);
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return abalanceReoaad;
        }


    }
}
