﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class PaymentDetailsDAO:BDGetWay
    {
        public List<PaymentDetail> ShowDailyReport()
        {
            List<PaymentDetail> paymentDetails = new List<PaymentDetail>();

            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("SELECT * from PaymentDetails");
                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        PaymentDetail paymentDetail = new PaymentDetail();
                        paymentDetail = ToReadPaymentInformation(reader);
                        paymentDetails.Add(paymentDetail);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return paymentDetails;
        }

        private PaymentDetail ToReadPaymentInformation(SqlDataReader reader)
        {
            PaymentDetail paymentDetail = new PaymentDetail();

            try
            {
                if (reader["PaymentDetailID"] != DBNull.Value)
                {
                    paymentDetail.PaymentDetailID = Convert.ToInt32(reader["PaymentDetailID"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Subtotal"] != DBNull.Value)
                {
                    paymentDetail.Subtotal = Convert.ToDouble(reader["Subtotal"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Discount"] != DBNull.Value)
                {
                    paymentDetail.Discount = Convert.ToDouble(reader["Discount"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["ServiceTex"] != DBNull.Value)
                {
                    paymentDetail.ServiceTex = Convert.ToDouble(reader["ServiceTex"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["GST"] != DBNull.Value)
                {
                    paymentDetail.GST = Convert.ToDouble(reader["GST"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Rounding"] != DBNull.Value)
                {
                    paymentDetail.Rounding = Convert.ToDouble(reader["Rounding"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["GrandTotal"] != DBNull.Value)
                {
                    paymentDetail.GrandTotal = Convert.ToDouble(reader["GrandTotal"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["UserId"] != DBNull.Value)
                {
                    paymentDetail.UserId = reader["UserId"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["SixDigitPin"] != DBNull.Value)
                {
                    paymentDetail.SixDigitPin = reader["SixDigitPin"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["DailyReportDate"] != DBNull.Value)
                {
                    paymentDetail.DailyReportDate = Convert.ToDateTime(reader["DailyReportDate"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["AccountBalance"] != DBNull.Value)
                {
                    paymentDetail.AccountBalance = Convert.ToDouble(reader["AccountBalance"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["MadePayment"] != DBNull.Value)
                {
                    paymentDetail.MadePayment = Convert.ToDouble(reader["MadePayment"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["NewBalance"] != DBNull.Value)
                {
                    paymentDetail.NewBalance = Convert.ToDouble(reader["NewBalance"]);
                }
            }
            catch
            {
            }

            return paymentDetail;
        }

        public string InsertPayment(PaymentDetail paymentDetail)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into PaymentDetails values ({0},{1},{2},{3},{4},{5},'{6}','{7}','{8}',{9},{10},{11});",
                    paymentDetail.Subtotal, paymentDetail.Discount, paymentDetail.ServiceTex,
                    paymentDetail.GST, paymentDetail.Rounding, paymentDetail.GrandTotal, paymentDetail.UserId,
                    paymentDetail.SixDigitPin, paymentDetail.DailyReportDate, paymentDetail.AccountBalance,
                    paymentDetail.MadePayment, paymentDetail.NewBalance);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Payment has been saved successfully.";
            }
            catch (Exception ex)
            {
                result = "Payment couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public DataTable ShowDateWiseReport(DateTime stDate)
        {
            DataTable aTable = new DataTable();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from PaymentDetails where DailyReportDate >='{0}';", stDate);

                SqlCommand cmd = new SqlCommand(query, SqlConnectionObj);
                using (SqlDataAdapter a = new SqlDataAdapter(cmd))
                {
                    a.Fill(aTable);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + ". Error Occured. Please contact to your administrator.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return aTable;
        }



    }
}
