﻿using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShopManagementSystem.DAL.DAO
{
    public class ProductDAO:BDGetWay
    {
        public string InsertProduct(Product product)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("insert into Product values ('{0}','{1}',{2},'{3}');",
                    product.ProductName, product.Category, product.Price, product.Size);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Product has been saved successfully.";
            }
            catch (Exception ex)
            {
                result = "Product couldn't saved.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public Product GetProductName(string name)
        {
            Product product = new Product();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from Product where ProductName='{0}'", name);

                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        product = ToReadAllProductInfo(reader);
                    }
                }


            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + ". Error Occured. Please contact to your administrator.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return product;
        }

        private Product ToReadAllProductInfo(SqlDataReader reader)
        {
            Product product = new Product();
            try
            {
                if (reader["ProductID"] != DBNull.Value)
                {
                    product.ProductID = Convert.ToInt32(reader["ProductID"]);
                }
            }
            catch
            {

            }

            try
            {
                if (reader["ProductName"] != DBNull.Value)
                {
                    product.ProductName = reader["ProductName"].ToString();
                }
            }
            catch
            {
            }
            
            try
            {
                if (reader["Category"] != DBNull.Value)
                {
                    product.Category = reader["Category"].ToString();
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Price"] != DBNull.Value)
                {
                    product.Price = Convert.ToDouble(reader["Price"]);
                }
            }
            catch
            {
            }

            try
            {
                if (reader["Size"] != DBNull.Value)
                {
                    product.Size = reader["Size"].ToString();
                }
            }
            catch
            {
            }

            return product;

        }

        

        public string UpdateProduct(Product product)
        {
            string result = "";
            try
            {
                SqlConnectionObj.Open();
                string sqlQuery = string.Format("UPDATE Product SET ProductName = '{1}',Category = '{2}',Price={3},Size='{4}' " +
                    "where ProductID = {0} ", product.ProductID, product.ProductName, product.Category, product.Price, product.Size);

                SqlSqlcommandObj.CommandText = sqlQuery;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = "Product updated Sucessfully.";

            }
            catch (Exception ex)
            {
                result = "Product couldn't updated.";
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }


        public bool DeleteProduct(int id)
        {
            bool result = false;
            try
            {
                SqlConnectionObj.Open();
                String Query = string.Format("DELETE FROM Product WHERE ProductID={0}", id);

                SqlSqlcommandObj.CommandText = Query;
                SqlSqlcommandObj.ExecuteNonQuery();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return result;
        }

        public Product GetAllProduct(int productOrderId)
        {
            Product product = new Product();
            try
            {
                SqlConnectionObj.Open();
                string query = string.Format("SELECT * from Product where ProductID='{0}'", productOrderId);

                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        product = ToReadAllProductInfo(reader);
                    }
                }


            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message + ". Error Occured. Please contact to your administrator.");
            }

            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }

            return product;
        }

        public List<Product> GetProductList()
        {
            List<Product> products = new List<Product>();
            try
            {


                SqlConnectionObj.Open();
                string query = String.Format("SELECT * FROM Product");
                SqlSqlcommandObj.CommandText = query;
                SqlDataReader reader = SqlSqlcommandObj.ExecuteReader();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        Product product = new Product();
                        product = ToReadAllProductInfo(reader);
                        products.Add(product);

                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception("Data not Found!!!", ex);

            }
            finally
            {
                if (SqlConnectionObj != null && SqlConnectionObj.State == ConnectionState.Open)
                {
                    SqlConnectionObj.Close();
                }
            }
            return products;
        }
    }
}
