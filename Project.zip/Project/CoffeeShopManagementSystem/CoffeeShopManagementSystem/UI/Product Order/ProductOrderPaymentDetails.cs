﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeShopManagementSystem.DAL.Model;
using CoffeeShopManagementSystem.BLL;

namespace CoffeeShopManagementSystem.UI.Product_Order
{
    public partial class ProductOrderPaymentDetails : UserControl
    {
        List<ProductOrder> productOrders = new List<ProductOrder>();
        ProductOrderBLL productOrderBLL = new ProductOrderBLL();

        public ProductOrderPaymentDetails()
        {
            InitializeComponent();
        }

        private void ProductOrderPaymentDetails_Load(object sender, EventArgs e)
        {
            List<Product> products = new List<Product>();
            ProductBLL productBLL = new ProductBLL();
            products = productBLL.GetProductList();

            selectedValue.DataSource = products;
            selectedValue.DisplayMember = "ProductName";
            selectedValue.ValueMember = "ProductID";
        }

        private void addOrderButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (quantityTextBox.Text == "")
                {
                    MessageBox.Show("Please check input field");
                    return;
                }
                else
                {

                    ProductOrder productOrder = new ProductOrder();

                    productOrder.ProductID = Convert.ToInt32(selectedValue.SelectedValue);
                    productOrder.ProductName = selectedValue.Text;
                    productOrder.Category = categoryTextBox.Text;

                    double p = Convert.ToDouble(priceTextBox.Text);
                    productOrder.Price = p;

                    productOrder.Size = sizeTextBox.Text;
                    int qty = Convert.ToInt32(quantityTextBox.Text);
                    productOrder.Quantity = qty;

                    productOrders.Add(productOrder);

                    paymentOrderInfo();


                    BindingSource bs = new BindingSource();
                    bs.DataSource = productOrders;
                    orderDataGridView.DataSource = bs;


                    //productOrderBLL.InsertProductOrder(productOrder);
                    quantityTextBox.Text = "";

                }
            }
            catch
            {

            }
        }

        private void paymentOrderInfo()
        {
            double sum = 0;
            foreach (ProductOrder aproductOrder in productOrders)
            {
                sum += aproductOrder.Price * aproductOrder.Quantity;
            }

            subTotalTextBox.Text = sum.ToString();
            double st = Convert.ToDouble(subTotalTextBox.Text);
            if (st <= 50)
            {
                rateDiscountTextBox.Text = "0";
            }
            else
            {
                rateDiscountTextBox.Text = "10";
            }
            
            double dr = Convert.ToDouble(rateDiscountTextBox.Text);
            double discount = st * (dr / 100);
            discountTextBox.Text = discount.ToString("F02");

            rateServiceTextBox.Text = "10";
            double sr = Convert.ToDouble(rateServiceTextBox.Text);
            double servicetex = (st - discount) * (sr/100);
            serviceTextBox.Text = servicetex.ToString("F02");

            rateGSTTextBox.Text = "6";
            double gr = Convert.ToDouble(rateGSTTextBox.Text);
            double tex = (st - discount) * (gr/100);
            gstTextBox.Text = tex.ToString("F02");
            
            double payment = 0;
            payment = (st - discount) + servicetex + tex;
            grandTotalTextBox.Text = payment.ToString("F02");
            paymentMadeTextBox.Text = payment.ToString("F02");

            double a = payment;
            double rounding = Math.Round(a*20)/20;
            double rounded = rounding - a;
            roundingTextBox.Text = rounded.ToString("F02");
            

        }

        private void selectedValue_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product product = new Product();
            ProductBLL productBLL = new ProductBLL();

            int id = Convert.ToInt32(selectedValue.SelectedValue);

            product = productBLL.GetAllProduct(id);

            categoryTextBox.Text = product.Category;
            priceTextBox.Text = product.Price.ToString();
            sizeTextBox.Text = product.Size;
        }

        private void orderDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            var DataGrideViewColumn = orderDataGridView.Columns["ProductOrderID"];
            if (DataGrideViewColumn != null) DataGrideViewColumn.Visible = false;

            var DataGrideViewColumn1 = orderDataGridView.Columns["ProductID"];
            if (DataGrideViewColumn1 != null) DataGrideViewColumn1.Visible = false;
        }

        private void paymentButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (userIDTextBox.Text == null || sixDigitePinTextBox.Text == null)
                {
                    MessageBox.Show("Please check input UserID and Six DigitPin.");
                    return;
                }
                else
                {
                    PaymentDetail paymentDetail = new PaymentDetail();
                    PaymentDetailsBLL paymentDetailsBLL = new PaymentDetailsBLL();

                    paymentDetail.DailyReportDate = DateTime.Now.Date;
                    paymentDetail.Subtotal = Convert.ToDouble(subTotalTextBox.Text);
                    paymentDetail.Discount = Convert.ToDouble(discountTextBox.Text);
                    paymentDetail.ServiceTex = Convert.ToDouble(serviceTextBox.Text);
                    paymentDetail.GST = Convert.ToDouble(gstTextBox.Text);
                    paymentDetail.Rounding = Convert.ToDouble(roundingTextBox.Text);

                    double gnd = Convert.ToDouble(grandTotalTextBox.Text);
                    paymentDetail.GrandTotal = gnd;

                    string userid = userIDTextBox.Text;
                    paymentDetail.UserId = userid;

                    string pin = sixDigitePinTextBox.Text;
                    paymentDetail.SixDigitPin = pin;

                    

                    CustomerEntry customerEntry = new CustomerEntry();
                    CustomerBLL customerBLL = new CustomerBLL();
                    customerEntry = customerBLL.GetAccountNumberAndAccontPin(userid, pin);
                    int custid = customerEntry.CustomerID;
                    if (customerEntry.AccountNumber == null || customerEntry.AccountPin == null)
                    {
                        MessageBox.Show("UserId and Six Digitpin don't match.");
                        return;
                    }

                    BalanceReoaad balanceReoaad = new BalanceReoaad();
                    BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();

                    balanceReoaad = balanceReloadBLL.GetByCustomerId(custid);

                    double abalance = balanceReoaad.Balance;
                    if (abalance < gnd)
                    {
                        MessageBox.Show("Insufficient balance.");
                        return;
                    }

                    double bbalance = abalance - gnd;
                    balanceReoaad.Balance = bbalance;
                    balanceReloadBLL.UpdateBalance(balanceReoaad);

                    paymentDetail.AccountBalance = Convert.ToDouble(accountBalanceTextBox.Text);
                    paymentDetail.MadePayment = Convert.ToDouble(paymentMadeTextBox.Text);
                    paymentDetail.NewBalance = Convert.ToDouble(newBalanceTextBox.Text);

                    string result = paymentDetailsBLL.InsertPayment(paymentDetail);
                    MessageBox.Show(result.ToString());

                    userIDTextBox.Text = "";
                    sixDigitePinTextBox.Text = "";
                }
                

            }
            catch
            {

            }
        }

        private void userIDTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                BalanceReoaad balanceReoaad = new BalanceReoaad();
                BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();

                string usId = userIDTextBox.Text;
                balanceReoaad = balanceReloadBLL.GetByAccountNumber(usId);

                double a = balanceReoaad.Balance;
                accountBalanceTextBox.Text = a.ToString("F02");

                double b = Convert.ToDouble(grandTotalTextBox.Text);
                double c = a - b;
                
                if (a > 0)
                {
                    newBalanceTextBox.Text = c.ToString("F02");
                }
                else
                {
                    newBalanceTextBox.Text = "";
                }


            }
            catch
            {

            }
        }
    }
}
