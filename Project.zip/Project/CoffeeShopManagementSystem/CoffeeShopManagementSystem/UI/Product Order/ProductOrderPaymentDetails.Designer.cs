﻿namespace CoffeeShopManagementSystem.UI.Product_Order
{
    partial class ProductOrderPaymentDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.categoryTextBox = new System.Windows.Forms.TextBox();
            this.selectedValue = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.sizeTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.addOrderButton = new System.Windows.Forms.Button();
            this.orderDataGridView = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.subTotalTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rateDiscountTextBox = new System.Windows.Forms.TextBox();
            this.discountTextBox = new System.Windows.Forms.TextBox();
            this.serviceTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rateServiceTextBox = new System.Windows.Forms.TextBox();
            this.gstTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rateGSTTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.roundingTextBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.grandTotalTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.userIDTextBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.sixDigitePinTextBox = new System.Windows.Forms.TextBox();
            this.paymentButton = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.accountBalanceTextBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.newBalanceTextBox = new System.Windows.Forms.TextBox();
            this.paymentMadeTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name";
            // 
            // categoryTextBox
            // 
            this.categoryTextBox.Location = new System.Drawing.Point(157, 51);
            this.categoryTextBox.Name = "categoryTextBox";
            this.categoryTextBox.ReadOnly = true;
            this.categoryTextBox.Size = new System.Drawing.Size(286, 20);
            this.categoryTextBox.TabIndex = 1;
            // 
            // selectedValue
            // 
            this.selectedValue.DisplayMember = "ProductName";
            this.selectedValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectedValue.FormattingEnabled = true;
            this.selectedValue.Location = new System.Drawing.Point(157, 24);
            this.selectedValue.Name = "selectedValue";
            this.selectedValue.Size = new System.Drawing.Size(286, 21);
            this.selectedValue.TabIndex = 2;
            this.selectedValue.ValueMember = "ProductID";
            this.selectedValue.SelectedIndexChanged += new System.EventHandler(this.selectedValue_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Price";
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(157, 77);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.ReadOnly = true;
            this.priceTextBox.Size = new System.Drawing.Size(286, 20);
            this.priceTextBox.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Size";
            // 
            // sizeTextBox
            // 
            this.sizeTextBox.Location = new System.Drawing.Point(157, 102);
            this.sizeTextBox.Name = "sizeTextBox";
            this.sizeTextBox.ReadOnly = true;
            this.sizeTextBox.Size = new System.Drawing.Size(286, 20);
            this.sizeTextBox.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Quantity";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(157, 128);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(286, 20);
            this.quantityTextBox.TabIndex = 1;
            // 
            // addOrderButton
            // 
            this.addOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addOrderButton.Location = new System.Drawing.Point(157, 180);
            this.addOrderButton.Name = "addOrderButton";
            this.addOrderButton.Size = new System.Drawing.Size(286, 49);
            this.addOrderButton.TabIndex = 2;
            this.addOrderButton.Text = "Add Order";
            this.addOrderButton.UseVisualStyleBackColor = true;
            this.addOrderButton.Click += new System.EventHandler(this.addOrderButton_Click);
            // 
            // orderDataGridView
            // 
            this.orderDataGridView.AllowUserToAddRows = false;
            this.orderDataGridView.AllowUserToDeleteRows = false;
            this.orderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderDataGridView.Location = new System.Drawing.Point(58, 261);
            this.orderDataGridView.Name = "orderDataGridView";
            this.orderDataGridView.ReadOnly = true;
            this.orderDataGridView.Size = new System.Drawing.Size(545, 150);
            this.orderDataGridView.TabIndex = 4;
            this.orderDataGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.orderDataGridView_DataBindingComplete);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(635, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Sub Total";
            // 
            // subTotalTextBox
            // 
            this.subTotalTextBox.Location = new System.Drawing.Point(761, 24);
            this.subTotalTextBox.Name = "subTotalTextBox";
            this.subTotalTextBox.ReadOnly = true;
            this.subTotalTextBox.Size = new System.Drawing.Size(286, 20);
            this.subTotalTextBox.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(635, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Discount";
            // 
            // rateDiscountTextBox
            // 
            this.rateDiscountTextBox.Location = new System.Drawing.Point(761, 54);
            this.rateDiscountTextBox.Name = "rateDiscountTextBox";
            this.rateDiscountTextBox.ReadOnly = true;
            this.rateDiscountTextBox.Size = new System.Drawing.Size(54, 20);
            this.rateDiscountTextBox.TabIndex = 1;
            // 
            // discountTextBox
            // 
            this.discountTextBox.Location = new System.Drawing.Point(856, 51);
            this.discountTextBox.Name = "discountTextBox";
            this.discountTextBox.ReadOnly = true;
            this.discountTextBox.Size = new System.Drawing.Size(191, 20);
            this.discountTextBox.TabIndex = 1;
            // 
            // serviceTextBox
            // 
            this.serviceTextBox.Location = new System.Drawing.Point(856, 80);
            this.serviceTextBox.Name = "serviceTextBox";
            this.serviceTextBox.ReadOnly = true;
            this.serviceTextBox.Size = new System.Drawing.Size(191, 20);
            this.serviceTextBox.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(635, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Service Tex";
            // 
            // rateServiceTextBox
            // 
            this.rateServiceTextBox.Location = new System.Drawing.Point(761, 80);
            this.rateServiceTextBox.Name = "rateServiceTextBox";
            this.rateServiceTextBox.ReadOnly = true;
            this.rateServiceTextBox.Size = new System.Drawing.Size(54, 20);
            this.rateServiceTextBox.TabIndex = 1;
            // 
            // gstTextBox
            // 
            this.gstTextBox.Location = new System.Drawing.Point(856, 105);
            this.gstTextBox.Name = "gstTextBox";
            this.gstTextBox.ReadOnly = true;
            this.gstTextBox.Size = new System.Drawing.Size(191, 20);
            this.gstTextBox.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(635, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "GST";
            // 
            // rateGSTTextBox
            // 
            this.rateGSTTextBox.Location = new System.Drawing.Point(761, 105);
            this.rateGSTTextBox.Name = "rateGSTTextBox";
            this.rateGSTTextBox.ReadOnly = true;
            this.rateGSTTextBox.Size = new System.Drawing.Size(54, 20);
            this.rateGSTTextBox.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(823, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(823, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "%";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(823, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "%";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(635, 145);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Rounding";
            // 
            // roundingTextBox
            // 
            this.roundingTextBox.Location = new System.Drawing.Point(761, 138);
            this.roundingTextBox.Name = "roundingTextBox";
            this.roundingTextBox.ReadOnly = true;
            this.roundingTextBox.Size = new System.Drawing.Size(286, 20);
            this.roundingTextBox.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(635, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Grand Total";
            // 
            // grandTotalTextBox
            // 
            this.grandTotalTextBox.Location = new System.Drawing.Point(761, 164);
            this.grandTotalTextBox.Name = "grandTotalTextBox";
            this.grandTotalTextBox.ReadOnly = true;
            this.grandTotalTextBox.Size = new System.Drawing.Size(286, 20);
            this.grandTotalTextBox.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(635, 206);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "User ID";
            // 
            // userIDTextBox
            // 
            this.userIDTextBox.Location = new System.Drawing.Point(761, 199);
            this.userIDTextBox.Name = "userIDTextBox";
            this.userIDTextBox.Size = new System.Drawing.Size(286, 20);
            this.userIDTextBox.TabIndex = 1;
            this.userIDTextBox.TextChanged += new System.EventHandler(this.userIDTextBox_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(635, 232);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Six Digite Pin";
            // 
            // sixDigitePinTextBox
            // 
            this.sixDigitePinTextBox.Location = new System.Drawing.Point(761, 225);
            this.sixDigitePinTextBox.Name = "sixDigitePinTextBox";
            this.sixDigitePinTextBox.Size = new System.Drawing.Size(286, 20);
            this.sixDigitePinTextBox.TabIndex = 2;
            this.sixDigitePinTextBox.UseSystemPasswordChar = true;
            // 
            // paymentButton
            // 
            this.paymentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentButton.Location = new System.Drawing.Point(761, 265);
            this.paymentButton.Name = "paymentButton";
            this.paymentButton.Size = new System.Drawing.Size(286, 56);
            this.paymentButton.TabIndex = 3;
            this.paymentButton.Text = "Make Payment";
            this.paymentButton.UseVisualStyleBackColor = true;
            this.paymentButton.Click += new System.EventHandler(this.paymentButton_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(635, 343);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Account Balance";
            // 
            // accountBalanceTextBox
            // 
            this.accountBalanceTextBox.Location = new System.Drawing.Point(761, 336);
            this.accountBalanceTextBox.Name = "accountBalanceTextBox";
            this.accountBalanceTextBox.ReadOnly = true;
            this.accountBalanceTextBox.Size = new System.Drawing.Size(286, 20);
            this.accountBalanceTextBox.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(635, 394);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "New Balance";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(635, 369);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Payment Made";
            // 
            // newBalanceTextBox
            // 
            this.newBalanceTextBox.Location = new System.Drawing.Point(761, 387);
            this.newBalanceTextBox.Name = "newBalanceTextBox";
            this.newBalanceTextBox.ReadOnly = true;
            this.newBalanceTextBox.Size = new System.Drawing.Size(286, 20);
            this.newBalanceTextBox.TabIndex = 1;
            // 
            // paymentMadeTextBox
            // 
            this.paymentMadeTextBox.Location = new System.Drawing.Point(761, 362);
            this.paymentMadeTextBox.Name = "paymentMadeTextBox";
            this.paymentMadeTextBox.ReadOnly = true;
            this.paymentMadeTextBox.Size = new System.Drawing.Size(286, 20);
            this.paymentMadeTextBox.TabIndex = 1;
            // 
            // ProductOrderPaymentDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.orderDataGridView);
            this.Controls.Add(this.paymentButton);
            this.Controls.Add(this.addOrderButton);
            this.Controls.Add(this.selectedValue);
            this.Controls.Add(this.sixDigitePinTextBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.userIDTextBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.quantityTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.paymentMadeTextBox);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(this.newBalanceTextBox);
            this.Controls.Add(this.sizeTextBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rateGSTTextBox);
            this.Controls.Add(this.rateServiceTextBox);
            this.Controls.Add(this.rateDiscountTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.gstTextBox);
            this.Controls.Add(this.serviceTextBox);
            this.Controls.Add(this.discountTextBox);
            this.Controls.Add(this.grandTotalTextBox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.roundingTextBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.subTotalTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.accountBalanceTextBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.categoryTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ProductOrderPaymentDetails";
            this.Size = new System.Drawing.Size(1157, 546);
            this.Load += new System.EventHandler(this.ProductOrderPaymentDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox categoryTextBox;
        private System.Windows.Forms.ComboBox selectedValue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox sizeTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.Button addOrderButton;
        private System.Windows.Forms.DataGridView orderDataGridView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox subTotalTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox rateDiscountTextBox;
        private System.Windows.Forms.TextBox discountTextBox;
        private System.Windows.Forms.TextBox serviceTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox rateServiceTextBox;
        private System.Windows.Forms.TextBox gstTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox rateGSTTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox roundingTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox grandTotalTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox userIDTextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox sixDigitePinTextBox;
        private System.Windows.Forms.Button paymentButton;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox accountBalanceTextBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox newBalanceTextBox;
        private System.Windows.Forms.TextBox paymentMadeTextBox;
    }
}
