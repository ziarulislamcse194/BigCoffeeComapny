﻿namespace CoffeeShopManagementSystem.UI.Balance_Reload
{
    partial class BalanceReloadForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.selectedValue = new System.Windows.Forms.ComboBox();
            this.balanceTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.balanceReloadButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Account Number";
            // 
            // selectedValue
            // 
            this.selectedValue.DisplayMember = "AccountNumber";
            this.selectedValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectedValue.FormattingEnabled = true;
            this.selectedValue.Location = new System.Drawing.Point(251, 40);
            this.selectedValue.Name = "selectedValue";
            this.selectedValue.Size = new System.Drawing.Size(307, 21);
            this.selectedValue.TabIndex = 1;
            this.selectedValue.ValueMember = "CustomerID";
            this.selectedValue.SelectedIndexChanged += new System.EventHandler(this.selectedValue_SelectedIndexChanged);
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(251, 132);
            this.balanceTextBox.Name = "balanceTextBox";
            this.balanceTextBox.Size = new System.Drawing.Size(307, 20);
            this.balanceTextBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(101, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Balance";
            // 
            // balanceReloadButton
            // 
            this.balanceReloadButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceReloadButton.Location = new System.Drawing.Point(251, 176);
            this.balanceReloadButton.Name = "balanceReloadButton";
            this.balanceReloadButton.Size = new System.Drawing.Size(307, 54);
            this.balanceReloadButton.TabIndex = 3;
            this.balanceReloadButton.Text = "Balance Reload";
            this.balanceReloadButton.UseVisualStyleBackColor = true;
            this.balanceReloadButton.Click += new System.EventHandler(this.balanceReloadButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(101, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Customer Name";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(251, 87);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.ReadOnly = true;
            this.nameTextBox.Size = new System.Drawing.Size(307, 20);
            this.nameTextBox.TabIndex = 2;
            // 
            // BalanceReloadForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.balanceReloadButton);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.balanceTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.selectedValue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "BalanceReloadForm";
            this.Size = new System.Drawing.Size(702, 260);
            this.Load += new System.EventHandler(this.BalanceReloadForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox selectedValue;
        private System.Windows.Forms.TextBox balanceTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button balanceReloadButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameTextBox;
    }
}
