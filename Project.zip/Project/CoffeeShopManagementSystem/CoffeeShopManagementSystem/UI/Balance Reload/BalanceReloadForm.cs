﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeShopManagementSystem.DAL.Model;
using CoffeeShopManagementSystem.BLL;

namespace CoffeeShopManagementSystem.UI.Balance_Reload
{
    public partial class BalanceReloadForm : UserControl
    {
        public BalanceReloadForm()
        {
            InitializeComponent();
        }

        private void BalanceReloadForm_Load(object sender, EventArgs e)
        {
            List<CustomerEntry> customerEntries = new List<CustomerEntry>();
            CustomerBLL customerBLL = new CustomerBLL();
            customerEntries = customerBLL.GetCustomerList();

            selectedValue.DataSource = customerEntries;
            selectedValue.DisplayMember = "AccountNumber";
            selectedValue.ValueMember = "CustomerID";

            LoadCustomerName();

        }

        private void LoadCustomerName()
        {
            try
            {
                int id = Convert.ToInt32(selectedValue.SelectedValue);
                CustomerEntry customerEntry = new CustomerEntry();
                CustomerBLL customerBLL = new CustomerBLL();
                customerEntry = customerBLL.GetByCustomerId(id);
                nameTextBox.Text = customerEntry.Name;
            }
            catch
            {

            }
        }

        private void balanceReloadButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (balanceTextBox.Text == "")
                {
                    MessageBox.Show("Please check input field");
                    return;
                }
                else
                {
                    BalanceReoaad balanceReoaad = new BalanceReoaad();
                    BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();

                    balanceReoaad.CustomerID = Convert.ToInt32(selectedValue.SelectedValue);
                    balanceReoaad.AccountNumber = selectedValue.Text;
                    balanceReoaad.CustomerName = nameTextBox.Text;
                    balanceReoaad.Balance = Convert.ToDouble(balanceTextBox.Text);

                    string result = balanceReloadBLL.InsertBalance(balanceReoaad);
                    MessageBox.Show(result).ToString();
                    balanceTextBox.Text = "";
                }
            }
            catch
            {

            }
        }

        private void selectedValue_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadCustomerName();
        }
    }
}
