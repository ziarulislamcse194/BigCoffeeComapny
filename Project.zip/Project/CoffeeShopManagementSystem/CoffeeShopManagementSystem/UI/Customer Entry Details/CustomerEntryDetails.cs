﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeShopManagementSystem.DAL.Model;
using CoffeeShopManagementSystem.BLL;

namespace CoffeeShopManagementSystem.UI.Customer_Entry_Details
{
    public partial class CustomerEntryDetails : UserControl
    {
        private int id = 0;

        public CustomerEntryDetails()
        {
            InitializeComponent();
        }
        
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (checkInfo())
            {
                CustomerEntry customerEntry = new CustomerEntry();
                CustomerBLL customerBLL = new CustomerBLL();

                customerEntry.Name = customerNameTextBox.Text;
                customerEntry.AccountNumber = accountNumberTextBox.Text;
                customerEntry.AccountPin = accountPinTextBox.Text;
                customerEntry.Address = addressTextBox.Text;
                customerEntry.ContactNumber = Convert.ToInt32(contactNumberTextBox.Text);

                string result = customerBLL.InsertCustomer(customerEntry);
                MessageBox.Show(result).ToString();

                customerNameTextBox.Text = "";
                accountNumberTextBox.Text = "";
                accountPinTextBox.Text = "";
                addressTextBox.Text = "";
                contactNumberTextBox.Text = "";

            }
        }

        private bool checkInfo()
        {
            if (customerNameTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on customer name.");
                return false;
            }

            if (accountNumberTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on account number.");
                return false;
            }

            if (accountPinTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on account pin.");
                return false;
            }

            if (addressTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on address.");
                return false;
            }


            int aNumber;
            bool isNumber = int.TryParse(contactNumberTextBox.Text.Trim(), out aNumber);
            if (!isNumber)
            {
                MessageBox.Show("put on int number.");
                return false;
            }


            return true;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            if (customerNameSerchTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("Please give correct input");
                return;
            }

            CustomerBLL customerBLL = new CustomerBLL();
            CustomerEntry customerEntry = new CustomerEntry();
            customerEntry = customerBLL.GetCustomerName(customerNameSerchTextBox.Text);


            customerNameTextBox.Text = customerEntry.Name;
            accountNumberTextBox.Text = customerEntry.AccountNumber;
            accountPinTextBox.Text = customerEntry.AccountPin;
            addressTextBox.Text = customerEntry.Address;
            contactNumberTextBox.Text = customerEntry.ContactNumber.ToString();
            id = customerEntry.CustomerID;

            updateButton.Visible = true;

        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (checkInfo())
            {
                CustomerEntry customerEntry = new CustomerEntry();
                CustomerBLL customerBLL = new CustomerBLL();

                customerEntry.CustomerID = id;
                customerEntry.Name = customerNameTextBox.Text;
                customerEntry.AccountNumber = accountNumberTextBox.Text;
                customerEntry.AccountPin = accountPinTextBox.Text;
                customerEntry.Address = addressTextBox.Text;
                customerEntry.ContactNumber = Convert.ToInt32(contactNumberTextBox.Text);

                string result = customerBLL.UpdateCustomer(customerEntry);
                MessageBox.Show(result).ToString();

                customerNameTextBox.Text = "";
                accountNumberTextBox.Text = "";
                accountPinTextBox.Text = "";
                addressTextBox.Text = "";
                contactNumberTextBox.Text = "";
                customerNameSerchTextBox.Text = "";
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            
            CustomerBLL customerBLL = new CustomerBLL();
            bool aCustomer = customerBLL.DeleteCustomer(id);

            if (!aCustomer)
            {
                MessageBox.Show("Don't Delete.");
                return;
            }

            MessageBox.Show("Customer has been Delete Successfully.");
            customerNameTextBox.Text = "";
            accountNumberTextBox.Text = "";
            accountPinTextBox.Text = "";
            addressTextBox.Text = "";
            contactNumberTextBox.Text = "";
            customerNameSerchTextBox.Text = "";
        }
    }
}
