﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeShopManagementSystem.DAL.Model;
using CoffeeShopManagementSystem.BLL;

namespace CoffeeShopManagementSystem.UI.BalanceTransfer
{
    public partial class BalanceTransferForm : UserControl
    {
        public BalanceTransferForm()
        {
            InitializeComponent();
        }

        private void BalanceTransferForm_Load(object sender, EventArgs e)
        {
            LoadBalanceTransfer();
            LoadBalanceReceive();
        }

        private void LoadBalanceReceive()
        {
            List<CustomerEntry> customerEntries = new List<CustomerEntry>();
            CustomerBLL customerBLL = new CustomerBLL();
            customerEntries = customerBLL.GetCustomerList();

            selectedValue1.DataSource = customerEntries;
            selectedValue1.DisplayMember = "AccountNumber";
            selectedValue1.ValueMember = "CustomerID";

            LoadReceiveCustomerName();
        }

        private void LoadReceiveCustomerName()
        {
            try
            {
                int id = Convert.ToInt32(selectedValue.SelectedValue);
                CustomerEntry customerEntry = new CustomerEntry();
                CustomerBLL customerBLL = new CustomerBLL();
                customerEntry = customerBLL.GetByCustomerId(id);
                receiveCustomerNameTextBox.Text = customerEntry.Name;
            }
            catch
            {

            }
        }

        private void LoadBalanceTransfer()
        {
            List<CustomerEntry> customerEntries = new List<CustomerEntry>();
            CustomerBLL customerBLL = new CustomerBLL();
            customerEntries = customerBLL.GetCustomerList();

            selectedValue.DataSource = customerEntries;
            selectedValue.DisplayMember = "AccountNumber";
            selectedValue.ValueMember = "CustomerID";

            LoadTransferCustomerName();
        }

        private void LoadTransferCustomerName()
        {
            try
            {
                int id = Convert.ToInt32(selectedValue.SelectedValue);
                CustomerEntry customerEntry = new CustomerEntry();
                CustomerBLL customerBLL = new CustomerBLL();
                customerEntry = customerBLL.GetByCustomerId(id);
                transferCustomerNameTextBox.Text = customerEntry.Name;
            }
            catch
            {

            }
        }

        private void balanceTransferButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (balanceTextBox.Text == "")
                {
                    MessageBox.Show("Please check input field");
                    return;
                }
                else
                {
                    BalanceTransferModel balanceTransferModel = new BalanceTransferModel();
                    BalabceTransferBLL balabceTransferBLL = new BalabceTransferBLL();

                    balanceTransferModel.BalanceTransferAccount = selectedValue.SelectedValue.ToString();
                    balanceTransferModel.TransferCustomerName = transferCustomerNameTextBox.Text;
                    balanceTransferModel.BalanceReceiveAccount = selectedValue1.SelectedValue.ToString();
                    balanceTransferModel.ReceiveCustomerName = receiveCustomerNameTextBox.Text;
                    int a = Convert.ToInt32(balanceTextBox.Text);
                    balanceTransferModel.TransferBalance = a;

                    BalanceReoaad balanceReoaad = new BalanceReoaad();
                    BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();
                    int id = Convert.ToInt32(selectedValue.SelectedValue);
                    balanceReoaad = balanceReloadBLL.GetByCustomerId(id);
                    double aBalance = balanceReoaad.Balance;


                    int aid = Convert.ToInt32(selectedValue1.SelectedValue);
                    balanceReoaad = balanceReloadBLL.GetByCustomerId(aid);
                    double bBalance = balanceReoaad.Balance;
                    double cBalance = a + bBalance;

                    double dbalance = aBalance - a;

                    if (aBalance < a || bBalance == 0)
                    {
                        MessageBox.Show("Insuficent Balance.");
                        return;
                    }


                    string result = balabceTransferBLL.InsertBalanceTransfer(balanceTransferModel);
                    MessageBox.Show(result.ToString());

                    LoadTransferBalanceUpdate(id, dbalance);
                    LoadReceiveBalanceUpdate(aid, cBalance);

                    balanceTextBox.Text = "";
                }
            }
            catch
            {

            }
        }

        private void LoadReceiveBalanceUpdate(int id, double balance)
        {
            BalanceReoaad balanceReoaad = new BalanceReoaad();
            BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();
            balanceReoaad = balanceReloadBLL.GetByCustomerId(id);
            
            balanceReoaad.Balance = balance;
            balanceReloadBLL.UpdateBalance(balanceReoaad);
        }

        private void LoadTransferBalanceUpdate(int id , double balance)
        {
            BalanceReoaad balanceReoaad = new BalanceReoaad();
            BalanceReloadBLL balanceReloadBLL = new BalanceReloadBLL();
            balanceReoaad = balanceReloadBLL.GetByCustomerId(id);
            
            balanceReoaad.Balance = balance;
            balanceReloadBLL.UpdateBalance(balanceReoaad);
        }

        private void selectedValue_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadTransferCustomerName();
        }

        private void selectedValue1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadReceiveCustomerName();
        }
    }
}
