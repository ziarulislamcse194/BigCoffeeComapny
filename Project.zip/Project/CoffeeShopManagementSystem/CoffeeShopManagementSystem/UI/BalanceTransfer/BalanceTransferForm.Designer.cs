﻿namespace CoffeeShopManagementSystem.UI.BalanceTransfer
{
    partial class BalanceTransferForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.selectedValue = new System.Windows.Forms.ComboBox();
            this.selectedValue1 = new System.Windows.Forms.ComboBox();
            this.balanceTextBox = new System.Windows.Forms.TextBox();
            this.balanceTransferButton = new System.Windows.Forms.Button();
            this.receiveCustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.transferCustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Balance Transfer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Balance";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(552, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Balance Receive";
            // 
            // selectedValue
            // 
            this.selectedValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectedValue.FormattingEnabled = true;
            this.selectedValue.Location = new System.Drawing.Point(191, 54);
            this.selectedValue.Name = "selectedValue";
            this.selectedValue.Size = new System.Drawing.Size(241, 21);
            this.selectedValue.TabIndex = 8;
            this.selectedValue.SelectedIndexChanged += new System.EventHandler(this.selectedValue_SelectedIndexChanged);
            // 
            // selectedValue1
            // 
            this.selectedValue1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectedValue1.FormattingEnabled = true;
            this.selectedValue1.Location = new System.Drawing.Point(654, 54);
            this.selectedValue1.Name = "selectedValue1";
            this.selectedValue1.Size = new System.Drawing.Size(246, 21);
            this.selectedValue1.TabIndex = 7;
            this.selectedValue1.SelectedIndexChanged += new System.EventHandler(this.selectedValue1_SelectedIndexChanged);
            // 
            // balanceTextBox
            // 
            this.balanceTextBox.Location = new System.Drawing.Point(191, 152);
            this.balanceTextBox.Name = "balanceTextBox";
            this.balanceTextBox.Size = new System.Drawing.Size(241, 20);
            this.balanceTextBox.TabIndex = 9;
            // 
            // balanceTransferButton
            // 
            this.balanceTransferButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceTransferButton.Location = new System.Drawing.Point(306, 214);
            this.balanceTransferButton.Name = "balanceTransferButton";
            this.balanceTransferButton.Size = new System.Drawing.Size(373, 64);
            this.balanceTransferButton.TabIndex = 10;
            this.balanceTransferButton.Text = "Balance Transfer";
            this.balanceTransferButton.UseVisualStyleBackColor = true;
            this.balanceTransferButton.Click += new System.EventHandler(this.balanceTransferButton_Click);
            // 
            // receiveCustomerNameTextBox
            // 
            this.receiveCustomerNameTextBox.Location = new System.Drawing.Point(659, 108);
            this.receiveCustomerNameTextBox.Name = "receiveCustomerNameTextBox";
            this.receiveCustomerNameTextBox.ReadOnly = true;
            this.receiveCustomerNameTextBox.Size = new System.Drawing.Size(241, 20);
            this.receiveCustomerNameTextBox.TabIndex = 13;
            // 
            // transferCustomerNameTextBox
            // 
            this.transferCustomerNameTextBox.Location = new System.Drawing.Point(191, 106);
            this.transferCustomerNameTextBox.Name = "transferCustomerNameTextBox";
            this.transferCustomerNameTextBox.ReadOnly = true;
            this.transferCustomerNameTextBox.Size = new System.Drawing.Size(241, 20);
            this.transferCustomerNameTextBox.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(522, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Receive Customer Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Transfer Customer Name";
            // 
            // BalanceTransferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.receiveCustomerNameTextBox);
            this.Controls.Add(this.transferCustomerNameTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.balanceTransferButton);
            this.Controls.Add(this.balanceTextBox);
            this.Controls.Add(this.selectedValue1);
            this.Controls.Add(this.selectedValue);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "BalanceTransferForm";
            this.Size = new System.Drawing.Size(940, 315);
            this.Load += new System.EventHandler(this.BalanceTransferForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox selectedValue;
        private System.Windows.Forms.ComboBox selectedValue1;
        private System.Windows.Forms.TextBox balanceTextBox;
        private System.Windows.Forms.Button balanceTransferButton;
        private System.Windows.Forms.TextBox receiveCustomerNameTextBox;
        private System.Windows.Forms.TextBox transferCustomerNameTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}
