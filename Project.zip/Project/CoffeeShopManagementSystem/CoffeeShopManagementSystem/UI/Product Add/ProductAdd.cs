﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeShopManagementSystem.DAL.Model;
using CoffeeShopManagementSystem.BLL;

namespace CoffeeShopManagementSystem.UI.Product_Add
{
    public partial class ProductAdd : UserControl
    {
        private int id = 0;

        public ProductAdd()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (checkInfo())
            {
                Product product = new Product();
                ProductBLL productBLL = new ProductBLL();

                product.ProductName = productNameTextBox.Text;
                product.Category = categoryTextBox.Text;
                product.Price = Convert.ToDouble(priceTextBox.Text);
                product.Size = sizeTextBox.Text;

                string result = productBLL.InsertProduct(product);
                MessageBox.Show(result).ToString();

                productNameTextBox.Text = "";
                categoryTextBox.Text = "";
                priceTextBox.Text = "";
                sizeTextBox.Text = "";

                LoadAllProduct();

            }
        }

        private bool checkInfo()
        {
            if (productNameTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on product name.");
                return false;
            }

            if (categoryTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on product category.");
                return false;
            }

            if (priceTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on product price.");
                return false;
            }

            if (sizeTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("put on product size.");
                return false;
            }
            
            return true;
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (checkInfo())
            {
                Product product = new Product();
                ProductBLL productBLL = new ProductBLL();

                product.ProductID = id;
                product.ProductName = productNameTextBox.Text;
                product.Category = categoryTextBox.Text;
                product.Price = Convert.ToDouble(priceTextBox.Text);
                product.Size = sizeTextBox.Text;

                string result = productBLL.UpdateProduct(product);
                MessageBox.Show(result).ToString();

                productNameTextBox.Text = "";
                categoryTextBox.Text = "";
                priceTextBox.Text = "";
                sizeTextBox.Text = "";
                productNameSerchTextBox.Text = "";

                LoadAllProduct();
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            ProductBLL productBLL = new ProductBLL();
            bool aProduct = productBLL.DeleteProduct(id);

            if (!aProduct)
            {
                MessageBox.Show("Don't Delete.");
                return;
            }

            MessageBox.Show("Product has been Delete Successfully.");
            productNameTextBox.Text = "";
            categoryTextBox.Text = "";
            priceTextBox.Text = "";
            sizeTextBox.Text = "";
            productNameSerchTextBox.Text = "";
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            if (productNameSerchTextBox.Text.Trim().Length == 0)
            {
                MessageBox.Show("Please give correct input");
                return;
            }


            ProductBLL productBLL = new ProductBLL();
            Product product = new Product();

            product = productBLL.GetProductName(productNameSerchTextBox.Text);

            productNameTextBox.Text = product.ProductName;
            categoryTextBox.Text = product.Category;
            priceTextBox.Text = product.Price.ToString();
            sizeTextBox.Text = product.Size;
            id = product.ProductID;

            updateButton.Visible = true;



        }

        private void ProductAdd_Load(object sender, EventArgs e)
        {
            LoadAllProduct();
        }

        private void LoadAllProduct()
        {
            ProductBLL productBLL = new ProductBLL();
            List<Product> products = new List<Product>();

            products = productBLL.GetProductList();
            productAddDataGridView.DataSource = products;
        }

        private void productAddDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            var DataGrideViewColumn = productAddDataGridView.Columns["ProductID"];
            if (DataGrideViewColumn != null) DataGrideViewColumn.Visible = false;
        }
    }
}
