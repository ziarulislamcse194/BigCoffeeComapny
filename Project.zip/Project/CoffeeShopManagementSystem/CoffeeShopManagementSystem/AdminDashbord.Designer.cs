﻿namespace CoffeeShopManagementSystem
{
    partial class AdminDashbord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashbord));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.customerEntryButton = new System.Windows.Forms.ToolStripButton();
            this.balanceReloadButton = new System.Windows.Forms.ToolStripButton();
            this.balanceTransferButton = new System.Windows.Forms.ToolStripButton();
            this.productSetupButton = new System.Windows.Forms.ToolStripButton();
            this.productOrderButton = new System.Windows.Forms.ToolStripButton();
            this.dailyReportButton = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.adminpanel = new System.Windows.Forms.Panel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerEntryButton,
            this.balanceReloadButton,
            this.balanceTransferButton,
            this.productSetupButton,
            this.productOrderButton,
            this.dailyReportButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(151, 450);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // customerEntryButton
            // 
            this.customerEntryButton.AutoSize = false;
            this.customerEntryButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.customerEntryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.customerEntryButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerEntryButton.ForeColor = System.Drawing.SystemColors.Control;
            this.customerEntryButton.Image = ((System.Drawing.Image)(resources.GetObject("customerEntryButton.Image")));
            this.customerEntryButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.customerEntryButton.Name = "customerEntryButton";
            this.customerEntryButton.Size = new System.Drawing.Size(150, 50);
            this.customerEntryButton.Text = "Customer Entry";
            this.customerEntryButton.Click += new System.EventHandler(this.customerEntryButton_Click);
            // 
            // balanceReloadButton
            // 
            this.balanceReloadButton.AutoSize = false;
            this.balanceReloadButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.balanceReloadButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.balanceReloadButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceReloadButton.ForeColor = System.Drawing.SystemColors.Control;
            this.balanceReloadButton.Image = ((System.Drawing.Image)(resources.GetObject("balanceReloadButton.Image")));
            this.balanceReloadButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.balanceReloadButton.Name = "balanceReloadButton";
            this.balanceReloadButton.Size = new System.Drawing.Size(150, 50);
            this.balanceReloadButton.Text = "Balance Reload";
            this.balanceReloadButton.Click += new System.EventHandler(this.customerReloadButton_Click);
            // 
            // balanceTransferButton
            // 
            this.balanceTransferButton.AutoSize = false;
            this.balanceTransferButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.balanceTransferButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.balanceTransferButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balanceTransferButton.ForeColor = System.Drawing.SystemColors.Control;
            this.balanceTransferButton.Image = ((System.Drawing.Image)(resources.GetObject("balanceTransferButton.Image")));
            this.balanceTransferButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.balanceTransferButton.Name = "balanceTransferButton";
            this.balanceTransferButton.Size = new System.Drawing.Size(150, 50);
            this.balanceTransferButton.Text = "Balance Transfer";
            this.balanceTransferButton.Click += new System.EventHandler(this.balanceTransferButton_Click);
            // 
            // productSetupButton
            // 
            this.productSetupButton.AutoSize = false;
            this.productSetupButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.productSetupButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.productSetupButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productSetupButton.ForeColor = System.Drawing.SystemColors.Control;
            this.productSetupButton.Image = ((System.Drawing.Image)(resources.GetObject("productSetupButton.Image")));
            this.productSetupButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.productSetupButton.Name = "productSetupButton";
            this.productSetupButton.Size = new System.Drawing.Size(150, 50);
            this.productSetupButton.Text = "Product Setup";
            this.productSetupButton.Click += new System.EventHandler(this.productSetupButton_Click);
            // 
            // productOrderButton
            // 
            this.productOrderButton.AutoSize = false;
            this.productOrderButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.productOrderButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.productOrderButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productOrderButton.ForeColor = System.Drawing.SystemColors.Control;
            this.productOrderButton.Image = ((System.Drawing.Image)(resources.GetObject("productOrderButton.Image")));
            this.productOrderButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.productOrderButton.Name = "productOrderButton";
            this.productOrderButton.Size = new System.Drawing.Size(150, 50);
            this.productOrderButton.Text = "Product Order";
            this.productOrderButton.Click += new System.EventHandler(this.productOrderButton_Click);
            // 
            // dailyReportButton
            // 
            this.dailyReportButton.AutoSize = false;
            this.dailyReportButton.BackColor = System.Drawing.SystemColors.GrayText;
            this.dailyReportButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.dailyReportButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dailyReportButton.ForeColor = System.Drawing.SystemColors.Control;
            this.dailyReportButton.Image = ((System.Drawing.Image)(resources.GetObject("dailyReportButton.Image")));
            this.dailyReportButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.dailyReportButton.Name = "dailyReportButton";
            this.dailyReportButton.Size = new System.Drawing.Size(150, 50);
            this.dailyReportButton.Text = "Daily Report";
            this.dailyReportButton.Click += new System.EventHandler(this.dailyReportButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(151, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(649, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // adminpanel
            // 
            this.adminpanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.adminpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adminpanel.Location = new System.Drawing.Point(151, 0);
            this.adminpanel.Name = "adminpanel";
            this.adminpanel.Size = new System.Drawing.Size(649, 428);
            this.adminpanel.TabIndex = 3;
            // 
            // AdminDashbord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.adminpanel);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "AdminDashbord";
            this.Text = "Big Coffee Company";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton customerEntryButton;
        private System.Windows.Forms.ToolStripButton balanceReloadButton;
        private System.Windows.Forms.ToolStripButton balanceTransferButton;
        private System.Windows.Forms.ToolStripButton productSetupButton;
        private System.Windows.Forms.ToolStripButton productOrderButton;
        private System.Windows.Forms.ToolStripButton dailyReportButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel adminpanel;
    }
}

