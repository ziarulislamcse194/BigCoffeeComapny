﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class BalabceTransferBLL
    {
        BalanceTransferDAO balanceTransferDAO = new BalanceTransferDAO();
        public string InsertBalanceTransfer(BalanceTransferModel balanceTransferModel)
        {
            string result = balanceTransferDAO.InsertBalanceTransfer(balanceTransferModel);
            return result;
        }
    }
}
