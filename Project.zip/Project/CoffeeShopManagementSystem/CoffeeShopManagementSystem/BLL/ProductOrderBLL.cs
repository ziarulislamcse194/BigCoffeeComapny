﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class ProductOrderBLL
    {
        ProductOrderDAO aProductOrderDAO = new ProductOrderDAO();

        public string InsertProductOrder(ProductOrder productOrder)
        {
            string result = aProductOrderDAO.InsertProductOrder(productOrder);
            return result;
        }


        public bool DeleteProductOrder(int id)
        {
            bool result = aProductOrderDAO.DeleteProductOrder(id);
            return result;
        }

        public List<ProductOrder> GetAllProductOrder()
        {
            return aProductOrderDAO.GetAllProductOrder();
        }
    }
}
