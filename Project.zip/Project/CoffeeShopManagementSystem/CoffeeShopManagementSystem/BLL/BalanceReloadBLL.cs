﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class BalanceReloadBLL
    {
        BalanceReloadDAO balanceReloadDAO = new BalanceReloadDAO();

        public string InsertBalance(BalanceReoaad balanceReoaad)
        {
            if (!Exit(balanceReoaad))
            {
                string result = balanceReloadDAO.InsertBalance(balanceReoaad);
                return result;
            }
            else
            {
                return "Account Numeber Already Exist";
            }
        }

        private bool Exit(BalanceReoaad balanceReoaad)
        {
            BalanceReoaad abalanceReoaad = new BalanceReoaad();
            abalanceReoaad = GetAllAccountNumber(balanceReoaad);
            int a = abalanceReoaad.CustomerID;
            if (a == 0)
            {
                return false;
            }
            
            return true;        
        }

        private BalanceReoaad GetAllAccountNumber(BalanceReoaad balanceReoaad)
        {
            BalanceReoaad abalanceReoaad = new BalanceReoaad();
            abalanceReoaad = balanceReloadDAO.GetAllAccountNumber(balanceReoaad);
            return abalanceReoaad;
        }

        public BalanceReoaad GetByCustomerId(int id)
        {
            BalanceReoaad balanceReoaad = new BalanceReoaad();
            return balanceReoaad = balanceReloadDAO.GetByCustomerId(id);
        }

        public string UpdateBalance(BalanceReoaad balanceReoaad)
        {
            string result = balanceReloadDAO.UpdateBalance(balanceReoaad);
            return result;
        }

        public BalanceReoaad GetByAccountNumber(string usId)
        {
            BalanceReoaad balanceReoaad = new BalanceReoaad();
            return balanceReoaad = balanceReloadDAO.GetByAccountNumber(usId);
        }


    }
}
