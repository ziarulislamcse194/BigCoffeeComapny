﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class ProductBLL
    {
        ProductDAO productDAO = new ProductDAO();

        public string InsertProduct(Product product)
        {
            string result = productDAO.InsertProduct(product);
            return result;
        }

        public Product GetProductName(string name)
        {
            Product product = new Product();
            product = productDAO.GetProductName(name);
            return product;
        }

        public string UpdateProduct(Product product)
        {
            string result;
            return result = productDAO.UpdateProduct(product);
        }

        public bool DeleteProduct(int id)
        {
            bool result = productDAO.DeleteProduct(id);
            return result;
        }

        public Product GetAllProduct(int productOrderId)
        {
            Product product = new Product();
            product = productDAO.GetAllProduct(productOrderId);
            return product;
        }

        public List<Product> GetProductList()
        {
            return productDAO.GetProductList();
        }
    }
}
