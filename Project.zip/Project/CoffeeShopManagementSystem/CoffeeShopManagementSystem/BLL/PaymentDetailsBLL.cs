﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class PaymentDetailsBLL
    {
        PaymentDetailsDAO paymentDetailsDAO = new PaymentDetailsDAO();

        public List<PaymentDetail> ShowDailyReport()
        {
            return paymentDetailsDAO.ShowDailyReport();
        }

        public string InsertPayment(PaymentDetail paymentDetail)
        {
            string result = paymentDetailsDAO.InsertPayment(paymentDetail);
            return result;
        }

        public DataTable ShowDateWiseReport(DateTime stDate)
        {
            return paymentDetailsDAO.ShowDateWiseReport(stDate);
        }


    }
}
