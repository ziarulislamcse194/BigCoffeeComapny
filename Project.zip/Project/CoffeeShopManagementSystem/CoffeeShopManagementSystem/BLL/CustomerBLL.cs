﻿using CoffeeShopManagementSystem.DAL.DAO;
using CoffeeShopManagementSystem.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopManagementSystem.BLL
{
    public class CustomerBLL
    {
        CustomerDAO aCustomerDAO = new CustomerDAO();

        public string InsertCustomer(CustomerEntry customerEntry)
        {
            string result = aCustomerDAO.InsertCustomer(customerEntry);
            return result;
        }

        public CustomerEntry GetCustomerName(string name)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            customerEntry = aCustomerDAO.GetCustomerName(name);
            return customerEntry;
        }

        public string UpdateCustomer(CustomerEntry customerEntry)
        {
            string result;
            return result = aCustomerDAO.UpdateCustomer(customerEntry);
        }

        public bool DeleteCustomer(int id)
        {
            bool result = aCustomerDAO.DeleteCustomer(id);
            return result;
        }

        public List<CustomerEntry> GetCustomerList()
        {
            return aCustomerDAO.GetCustomerList();
        }

        public CustomerEntry GetAccountNumberAndAccontPin(string userId, string sixdigitPin)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            customerEntry = aCustomerDAO.GetAccountNumberAndAccontPin(userId, sixdigitPin);
            return customerEntry;
        }

        public CustomerEntry GetByCustomerId(int id)
        {
            CustomerEntry customerEntry = new CustomerEntry();
            customerEntry = aCustomerDAO.GetByCustomerId(id);
            return customerEntry;
        }

    }
}
